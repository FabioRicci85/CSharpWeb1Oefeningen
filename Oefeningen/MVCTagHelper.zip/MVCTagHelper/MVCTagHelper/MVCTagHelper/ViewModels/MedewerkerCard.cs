﻿using MVCTagHelper.Models;

namespace MVCTagHelper.ViewModels
{
    public class MedewerkerCard : Medewerker
    {
        public int MedewerkerId { get; set; }
        public string MedewerkerNaam => base.Voornaam + " " + base.Naam;
        public string AfdelingNaam { get; set; }
    }
}
